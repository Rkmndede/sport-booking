-- ===== Company Sport Center Booking: schema + RLS + fungsi booking =====
create extension if not exists btree_gist;

create type app_role as enum ('employee','admin');
create type booking_status as enum ('pending','approved','rejected','cancelled');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  avatar_url text,
  role app_role not null default 'employee',
  is_verified boolean not null default false,
  created_at timestamptz not null default now()
);

-- Verifikasi karyawan: email spesifik (Gmail pribadi) ATAU domain perusahaan
create table allowed_employees (
  email text primary key check (email = lower(email)),
  full_name text,
  created_at timestamptz not null default now()
);
create table allowed_domains (
  domain text primary key check (domain = lower(domain))
);

create table facilities (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  is_active boolean not null default true,
  timezone text not null default 'Asia/Jakarta',
  open_time time not null default '08:00',
  close_time time not null default '21:00',
  slot_minutes int not null default 60 check (slot_minutes between 15 and 480),
  min_advance_hours int not null default 1 check (min_advance_hours >= 0),
  max_advance_days int not null default 14 check (max_advance_days >= 1),
  daily_limit int not null default 1 check (daily_limit >= 1),
  weekly_limit int not null default 3 check (weekly_limit >= 1),
  check (close_time > open_time)
);
create table facility_units (
  id uuid primary key default gen_random_uuid(),
  facility_id uuid not null references facilities(id) on delete cascade,
  name text not null,
  is_active boolean not null default true,
  unique (facility_id, name)
);
create table holidays (
  id uuid primary key default gen_random_uuid(),
  holiday_date date not null,
  description text,
  facility_id uuid references facilities(id) on delete cascade, -- null = semua fasilitas
  unique nulls not distinct (holiday_date, facility_id)
);
create table bookings (
  id uuid primary key default gen_random_uuid(),
  unit_id uuid not null references facility_units(id),
  user_id uuid not null references profiles(id),
  start_time timestamptz not null,
  end_time timestamptz not null,
  status booking_status not null default 'pending',
  note text,
  reject_reason text,
  decided_by uuid references profiles(id),
  decided_at timestamptz,
  created_at timestamptz not null default now(),
  check (end_time > start_time),
  -- ANTI DOUBLE BOOKING: dijamin PostgreSQL, aman untuk request bersamaan
  constraint no_overlap exclude using gist (
    unit_id with =, tstzrange(start_time, end_time) with &&
  ) where (status in ('pending','approved'))
);
create index on bookings (user_id, start_time);

-- ===== Helper role (security definer agar tidak rekursif di RLS) =====
create function is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and is_verified)
$$;
create function is_verified_user() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and is_verified)
$$;

-- ===== Profil otomatis saat login pertama. Role SELALU 'employee' =====
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, full_name, avatar_url, is_verified)
  values (new.id, lower(new.email),
    new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url',
    exists (select 1 from allowed_employees where email = lower(new.email))
      or exists (select 1 from allowed_domains where domain = split_part(lower(new.email),'@',2)));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- Jika admin menambah whitelist setelah user login, profil ikut terverifikasi
create function sync_verification() returns trigger language plpgsql security definer set search_path = public as $$
begin
  update profiles set is_verified = true
  where lower(email) = to_jsonb(new)->>'email' or split_part(lower(email),'@',2) = to_jsonb(new)->>'domain';
  return new;
end $$;
create trigger on_allowed_email after insert on allowed_employees for each row execute function sync_verification();
create trigger on_allowed_domain after insert on allowed_domains for each row execute function sync_verification();

-- ===== Booking: seluruh validasi di server =====
create function create_booking(p_unit_id uuid, p_start timestamptz, p_note text default null)
returns bookings language plpgsql security definer set search_path = public as $$
declare
  u facility_units; f facilities; v_end timestamptz;
  l_start timestamp; l_end timestamp; v_row bookings;
begin
  if not is_verified_user() then raise exception 'Akun belum terverifikasi sebagai karyawan'; end if;
  select * into u from facility_units where id = p_unit_id and is_active;
  if not found then raise exception 'Unit tidak tersedia'; end if;
  select * into f from facilities where id = u.facility_id and is_active;
  if not found then raise exception 'Fasilitas tidak aktif'; end if;

  v_end := p_start + make_interval(mins => f.slot_minutes);
  l_start := p_start at time zone f.timezone;
  l_end := v_end at time zone f.timezone;

  if l_start::time < f.open_time or l_end::date <> l_start::date or l_end::time > f.close_time then
    raise exception 'Di luar jam operasional'; end if;
  if mod(extract(epoch from (l_start::time - f.open_time))::int, f.slot_minutes * 60) <> 0 then
    raise exception 'Jam tidak sesuai durasi sesi'; end if;
  if p_start < now() + make_interval(hours => f.min_advance_hours) then
    raise exception 'Booking minimal % jam sebelumnya', f.min_advance_hours; end if;
  if p_start > now() + make_interval(days => f.max_advance_days) then
    raise exception 'Booking maksimal % hari ke depan', f.max_advance_days; end if;
  if exists (select 1 from holidays h where h.holiday_date = l_start::date
             and (h.facility_id is null or h.facility_id = f.id)) then
    raise exception 'Tanggal tersebut hari libur'; end if;

  -- serialkan cek kuota per user agar tidak bisa dilewati lewat request paralel
  perform pg_advisory_xact_lock(hashtext(auth.uid()::text));
  if (select count(*) from bookings b join facility_units fu on fu.id = b.unit_id
      where b.user_id = auth.uid() and fu.facility_id = f.id and b.status in ('pending','approved')
        and (b.start_time at time zone f.timezone)::date = l_start::date) >= f.daily_limit then
    raise exception 'Batas booking harian tercapai'; end if;
  if (select count(*) from bookings b join facility_units fu on fu.id = b.unit_id
      where b.user_id = auth.uid() and fu.facility_id = f.id and b.status in ('pending','approved')
        and date_trunc('week', b.start_time at time zone f.timezone) = date_trunc('week', l_start)) >= f.weekly_limit then
    raise exception 'Batas booking mingguan tercapai'; end if;

  begin
    insert into bookings (unit_id, user_id, start_time, end_time, note)
    values (p_unit_id, auth.uid(), p_start, v_end, left(p_note, 300)) returning * into v_row;
  exception when exclusion_violation then
    raise exception 'Slot sudah dibooking orang lain';
  end;
  return v_row;
end $$;

create function decide_booking(p_id uuid, p_approve boolean, p_reason text default null)
returns bookings language plpgsql security definer set search_path = public as $$
declare v_row bookings;
begin
  if not is_admin() then raise exception 'Hanya admin'; end if;
  select * into v_row from bookings where id = p_id for update;
  if not found or v_row.status <> 'pending' then raise exception 'Booking bukan berstatus pending'; end if;
  update bookings set
    status = case when p_approve then 'approved'::booking_status else 'rejected'::booking_status end,
    reject_reason = case when p_approve then null else p_reason end,
    decided_by = auth.uid(), decided_at = now()
  where id = p_id returning * into v_row;
  return v_row;
end $$;

create function cancel_booking(p_id uuid) returns bookings language plpgsql security definer set search_path = public as $$
declare v_row bookings;
begin
  select * into v_row from bookings where id = p_id for update;
  if not found or (v_row.user_id <> auth.uid() and not is_admin()) then raise exception 'Booking tidak ditemukan'; end if;
  if v_row.status not in ('pending','approved') or v_row.start_time <= now() then
    raise exception 'Booking tidak bisa dibatalkan'; end if;
  update bookings set status = 'cancelled' where id = p_id returning * into v_row;
  return v_row;
end $$;

-- Slot terisi (tanpa membuka identitas pemesan ke karyawan lain)
create function get_busy_slots(p_unit_id uuid, p_from timestamptz, p_to timestamptz)
returns table (start_time timestamptz, end_time timestamptz) language sql stable security definer set search_path = public as $$
  select b.start_time, b.end_time from bookings b
  where is_verified_user() and b.unit_id = p_unit_id and b.status in ('pending','approved')
    and b.start_time < p_to and b.end_time > p_from
$$;

-- Laporan penggunaan (admin saja)
create function usage_report(p_from date, p_to date)
returns table (facility text, unit text, approved_count bigint, pending_count bigint, rejected_count bigint, hours_used numeric)
language sql stable security definer set search_path = public as $$
  select f.name, u.name,
    count(*) filter (where b.status='approved'), count(*) filter (where b.status='pending'),
    count(*) filter (where b.status='rejected'),
    coalesce(sum(extract(epoch from b.end_time - b.start_time)/3600) filter (where b.status='approved'),0)
  from bookings b join facility_units u on u.id=b.unit_id join facilities f on f.id=u.facility_id
  where is_admin() and b.start_time >= p_from and b.start_time < p_to + 1
  group by f.name, u.name order by f.name, u.name
$$;

-- ===== Hak akses (default-deny) =====
alter table profiles enable row level security;
alter table allowed_employees enable row level security;
alter table allowed_domains enable row level security;
alter table facilities enable row level security;
alter table facility_units enable row level security;
alter table holidays enable row level security;
alter table bookings enable row level security;

revoke all on all tables in schema public from anon, authenticated;
grant select on profiles, facilities, facility_units, holidays, bookings, allowed_employees, allowed_domains to authenticated;
grant insert, update, delete on facilities, facility_units, holidays, allowed_employees, allowed_domains to authenticated;
grant update (full_name) on profiles to authenticated;  -- role & is_verified TIDAK bisa diubah lewat API
revoke execute on all functions in schema public from public, anon;
grant execute on function create_booking(uuid,timestamptz,text), decide_booking(uuid,boolean,text),
  cancel_booking(uuid), get_busy_slots(uuid,timestamptz,timestamptz), usage_report(date,date),
  is_admin(), is_verified_user() to authenticated;

create policy profiles_select on profiles for select using (id = auth.uid() or is_admin());
create policy profiles_update_self on profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy facilities_read on facilities for select using (is_verified_user());
create policy facilities_admin on facilities for all using (is_admin()) with check (is_admin());
create policy units_read on facility_units for select using (is_verified_user());
create policy units_admin on facility_units for all using (is_admin()) with check (is_admin());
create policy holidays_read on holidays for select using (is_verified_user());
create policy holidays_admin on holidays for all using (is_admin()) with check (is_admin());
create policy allowed_emp_admin on allowed_employees for all using (is_admin()) with check (is_admin());
create policy allowed_dom_admin on allowed_domains for all using (is_admin()) with check (is_admin());
-- bookings: tidak ada grant/policy insert-update-delete -> hanya lewat fungsi RPC di atas
create policy bookings_select on bookings for select using (user_id = auth.uid() or is_admin());

-- ===== Data awal =====
insert into facilities (name, description) values
 ('Badminton','Lapangan badminton indoor'),('Futsal','Lapangan futsal'),
 ('Tenis','Lapangan tenis'),('Gym & Biliard','Ruang gym dan meja biliard');
insert into facility_units (facility_id, name)
 select id, 'Lapangan 1' from facilities where name in ('Badminton','Futsal','Tenis')
 union all select id, 'Lapangan 2' from facilities where name = 'Badminton'
 union all select id, 'Gym' from facilities where name = 'Gym & Biliard'
 union all select id, 'Meja Biliard 1' from facilities where name = 'Gym & Biliard';
