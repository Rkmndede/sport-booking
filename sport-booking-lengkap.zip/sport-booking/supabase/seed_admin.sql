-- Jalankan SETELAH Anda login sekali dengan Google. Ganti email.
insert into allowed_employees (email) values ('admin@perusahaan.com') on conflict do nothing;
update profiles set role = 'admin', is_verified = true where lower(email) = 'admin@perusahaan.com';
-- Tambah karyawan: insert into allowed_employees (email) values ('budi@gmail.com');
-- Tambah domain:   insert into allowed_domains (domain) values ('perusahaan.com');
