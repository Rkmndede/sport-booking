import { Navigate } from 'react-router-dom'
import { useAuth } from '../auth/AuthProvider'

export default function Pending() {
  const { session, profile, signOut, refresh, loading } = useAuth()
  if (loading) return null
  if (!session) return <Navigate to="/login" replace />
  if (profile?.is_verified) return <Navigate to="/" replace />
  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 p-6">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow">
        <h1 className="text-xl font-semibold">Akun belum terverifikasi</h1>
        <p className="mt-2 text-sm text-slate-600">
          {session.user.email} belum terdaftar sebagai karyawan. Hubungi admin agar email ini
          ditambahkan, lalu tekan Cek ulang.
        </p>
        <div className="mt-6 flex gap-3">
          <button onClick={refresh} className="rounded-xl bg-emerald-700 px-4 py-2 text-white">Cek ulang</button>
          <button onClick={signOut} className="rounded-xl border px-4 py-2">Keluar</button>
        </div>
      </div>
    </main>
  )
}
