import { Navigate } from 'react-router-dom'
import { useAuth } from '../auth/AuthProvider'

export default function Login() {
  const { session, signIn, loading } = useAuth()
  if (!loading && session) return <Navigate to="/" replace />
  return (
    <main className="grid min-h-screen place-items-center bg-emerald-950 p-6">
      <div className="w-full max-w-sm rounded-2xl bg-white p-8 shadow-xl">
        <h1 className="text-2xl font-semibold text-slate-900">Sport Center</h1>
        <p className="mt-2 text-sm text-slate-600">
          Booking lapangan dan fasilitas olahraga untuk karyawan. Masuk dengan akun Google Anda.
        </p>
        <button
          onClick={signIn}
          className="mt-6 w-full rounded-xl bg-emerald-700 px-4 py-3 font-medium text-white hover:bg-emerald-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
        >
          Masuk dengan Google
        </button>
      </div>
    </main>
  )
}
