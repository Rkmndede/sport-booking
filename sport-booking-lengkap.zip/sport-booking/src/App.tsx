import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { AuthProvider, useAuth } from './auth/AuthProvider'
import { RequireEmployee } from './auth/Guards'
import Login from './pages/Login'
import Pending from './pages/Pending'

// Tahap 4 akan mengganti Home dengan Kalender/Booking/Riwayat dan halaman Admin
function Home() {
  const { profile, signOut } = useAuth()
  return (
    <main className="mx-auto max-w-3xl p-6">
      <p>Halo, {profile?.full_name ?? profile?.email} ({profile?.role})</p>
      <button onClick={signOut} className="mt-4 rounded-xl border px-4 py-2">Keluar</button>
    </main>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/pending" element={<Pending />} />
          <Route path="/" element={<RequireEmployee><Home /></RequireEmployee>} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}
