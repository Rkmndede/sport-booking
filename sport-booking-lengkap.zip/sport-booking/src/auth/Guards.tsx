import type { ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from './AuthProvider'

export function Spinner() {
  return <div className="grid min-h-screen place-items-center text-slate-500">Memuat…</div>
}

// Harus login DAN terverifikasi sebagai karyawan
export function RequireEmployee({ children }: { children: ReactNode }) {
  const { session, profile, loading } = useAuth()
  if (loading) return <Spinner />
  if (!session) return <Navigate to="/login" replace />
  if (!profile?.is_verified) return <Navigate to="/pending" replace />
  return <>{children}</>
}

// Hanya untuk tampilan. Keamanan sebenarnya ada di RLS & fungsi database.
export function RequireAdmin({ children }: { children: ReactNode }) {
  const { profile, loading } = useAuth()
  if (loading) return <Spinner />
  if (profile?.role !== 'admin') return <Navigate to="/" replace />
  return <>{children}</>
}
